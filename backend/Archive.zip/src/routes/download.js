const express = require('express')
const controller = require('../controllers/downloadController')
const { requireAuth } = require('../middleware/auth')

const router = express.Router()

router.get('/:pluginId', requireAuth, controller.download)

module.exports = router
