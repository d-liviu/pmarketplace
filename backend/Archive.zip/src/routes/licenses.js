const express = require('express')
const controller = require('../controllers/licenseController')
const { requireAuth } = require('../middleware/auth')

const router = express.Router()

router.get('/', requireAuth, controller.listLicenses)
router.get('/:pluginId', requireAuth, controller.getLicense)

module.exports = router
