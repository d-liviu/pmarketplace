const express = require('express')
const controller = require('../controllers/ordersController')
const { requireAuth } = require('../middleware/auth')

const router = express.Router()

router.get('/', requireAuth, controller.listOrders)
router.get('/:id/receipt', requireAuth, controller.downloadReceipt)

module.exports = router
