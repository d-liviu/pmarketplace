const express = require('express')
const controller = require('../controllers/cartController')
const { requireAuth } = require('../middleware/auth')

const router = express.Router()

router.get('/', requireAuth, controller.getCart)
router.post('/add', requireAuth, controller.addToCart)
router.delete('/remove', requireAuth, controller.removeFromCart)

module.exports = router
