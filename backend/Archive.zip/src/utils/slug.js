function toSlug(value) {
  if (!value) {
    return ''
  }

  return String(value)
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
}

module.exports = {
  toSlug
}
