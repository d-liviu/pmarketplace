const db = require('../config/db')
const { toSlug } = require('../utils/slug')
const { getPrimaryMediaMap } = require('./mediaService')

function normalizeTags(row) {
  if (!row.tags) {
    return []
  }
  return row.tags
    .split(',')
    .map((tag) => tag.trim())
    .filter(Boolean)
}

async function listPlugins({ includeDrafts = false, search = '', tag = '', price = '', version = '' } = {}) {
  const params = []
  const conditions = []

  if (!includeDrafts) {
    conditions.push('p.status = "published"')
  }

  if (search) {
    const term = `%${search}%`
    conditions.push(
      '(p.name LIKE ? OR p.short_description LIKE ? OR p.full_description LIKE ? OR t.name LIKE ?)'
    )
    params.push(term, term, term, term)
  }

  if (tag) {
    conditions.push('LOWER(t.name) = ?')
    params.push(tag.toLowerCase())
  }

  if (price == 'free') {
    conditions.push('p.is_free = 1')
  } else if (price == 'under-20') {
    conditions.push('p.price < 20')
  } else if (price == 'under-50') {
    conditions.push('p.price < 50')
  } else if (price == '50-plus') {
    conditions.push('p.price >= 50')
  }

  if (version) {
    const trimmedVersion = String(version).trim()
    if (trimmedVersion.toLowerCase().endsWith('x')) {
      const prefix = trimmedVersion.slice(0, -1)
      conditions.push('pv.pocketmine_version LIKE ?')
      params.push(`${prefix}%`)
    } else {
      conditions.push('pv.pocketmine_version = ?')
      params.push(trimmedVersion)
    }
  }

  const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : ''

  const [rows] = await db.query(
    `SELECT p.id, p.name, p.slug, p.short_description, p.price, p.is_free, p.featured, p.status, p.created_at, p.updated_at,
            GROUP_CONCAT(DISTINCT t.name ORDER BY t.name SEPARATOR ',') as tags
     FROM plugins p
     LEFT JOIN plugin_tags pt ON p.id = pt.plugin_id
     LEFT JOIN tags t ON pt.tag_id = t.id
     LEFT JOIN plugin_versions pv ON p.id = pv.plugin_id
     ${whereClause}
     GROUP BY p.id
     ORDER BY p.featured DESC, p.created_at DESC`,
    params
  )

  const plugins = rows.map((row) => ({
    ...row,
    tags: normalizeTags(row)
  }))

  const mediaMap = await getPrimaryMediaMap(plugins.map((plugin) => plugin.id))

  return plugins.map((plugin) => ({
    ...plugin,
    media: mediaMap[plugin.id] || []
  }))
}

async function getPluginBySlug(slug, { includeDrafts = false } = {}) {
  const params = [slug]
  let statusFilter = ''
  if (!includeDrafts) {
    statusFilter = 'AND p.status = "published"'
  }

  const [rows] = await db.query(
    `SELECT p.*, GROUP_CONCAT(DISTINCT t.name ORDER BY t.name SEPARATOR ',') as tags
     FROM plugins p
     LEFT JOIN plugin_tags pt ON p.id = pt.plugin_id
     LEFT JOIN tags t ON pt.tag_id = t.id
     WHERE p.slug = ? ${statusFilter}
     GROUP BY p.id
     LIMIT 1`,
    params
  )

  if (rows.length === 0) {
    return null
  }

  const row = rows[0]
  return {
    ...row,
    tags: normalizeTags(row)
  }
}

async function getPluginById(id) {
  const [rows] = await db.query('SELECT * FROM plugins WHERE id = ? LIMIT 1', [id])
  return rows[0] || null
}

async function ensureUniqueSlug(baseSlug, pluginId = null) {
  let slug = baseSlug
  let suffix = 1

  while (true) {
    const [rows] = await db.query('SELECT id FROM plugins WHERE slug = ? LIMIT 1', [slug])
    if (rows.length === 0 || (pluginId && rows[0].id === pluginId)) {
      return slug
    }
    slug = `${baseSlug}-${suffix}`
    suffix += 1
  }
}

async function createPlugin(payload) {
  const slugBase = payload.slug ? toSlug(payload.slug) : toSlug(payload.name)
  const slug = await ensureUniqueSlug(slugBase)

  const isFree = Boolean(payload.is_free)
  const price = isFree ? 0 : Number(payload.price || 0)

  const [result] = await db.query(
    `INSERT INTO plugins (name, slug, short_description, full_description, price, is_free, status, featured)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      payload.name,
      slug,
      payload.short_description || '',
      payload.full_description || '',
      price,
      isFree,
      payload.status || 'draft',
      Boolean(payload.featured)
    ]
  )

  return getPluginById(result.insertId)
}

async function updatePlugin(id, payload) {
  const existing = await getPluginById(id)
  if (!existing) {
    const error = new Error('Plugin not found')
    error.status = 404
    throw error
  }

  const name = payload.name ?? existing.name
  const slugInput = payload.slug ? toSlug(payload.slug) : toSlug(name)
  const slug = await ensureUniqueSlug(slugInput, id)
  const isFree = payload.is_free !== undefined ? Boolean(payload.is_free) : Boolean(existing.is_free)
  const price = isFree ? 0 : Number(payload.price ?? existing.price ?? 0)

  await db.query(
    `UPDATE plugins
     SET name = ?, slug = ?, short_description = ?, full_description = ?, price = ?, is_free = ?, status = ?, featured = ?, updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`,
    [
      name,
      slug,
      payload.short_description ?? existing.short_description,
      payload.full_description ?? existing.full_description,
      price,
      isFree,
      payload.status ?? existing.status,
      payload.featured ?? existing.featured,
      id
    ]
  )

  return getPluginById(id)
}

async function deletePlugin(id) {
  await db.query('DELETE FROM plugins WHERE id = ?', [id])
}

async function getVersions(pluginId) {
  const [rows] = await db.query(
    `SELECT id, plugin_id, version, changelog, pocketmine_version, created_at
     FROM plugin_versions WHERE plugin_id = ? ORDER BY created_at DESC`,
    [pluginId]
  )
  return rows
}

async function getMedia(pluginId) {
  const [rows] = await db.query(
    `SELECT id, plugin_id, type, url, position FROM plugin_media WHERE plugin_id = ? ORDER BY position ASC`,
    [pluginId]
  )
  return rows
}

async function getReviews(pluginId) {
  const [rows] = await db.query(
    `SELECT r.id, r.rating, r.comment, r.created_at, u.username
     FROM reviews r JOIN users u ON r.user_id = u.id
     WHERE r.plugin_id = ? ORDER BY r.created_at DESC`,
    [pluginId]
  )
  return rows
}

async function userHasPurchased(userId, pluginId) {
  const [rows] = await db.query(
    `SELECT oi.order_id
     FROM order_items oi
     JOIN orders o ON oi.order_id = o.id
     WHERE o.user_id = ? AND oi.plugin_id = ? AND o.status = 'paid' LIMIT 1`,
    [userId, pluginId]
  )
  return rows.length > 0
}

async function addReview({ pluginId, userId, rating, comment }) {
  const hasPurchased = await userHasPurchased(userId, pluginId)
  if (!hasPurchased) {
    const error = new Error('Purchase required to review')
    error.status = 403
    throw error
  }

  const [existing] = await db.query(
    'SELECT id FROM reviews WHERE user_id = ? AND plugin_id = ? LIMIT 1',
    [userId, pluginId]
  )
  if (existing.length > 0) {
    const error = new Error('Review already submitted')
    error.status = 409
    throw error
  }

  const [result] = await db.query(
    'INSERT INTO reviews (user_id, plugin_id, rating, comment) VALUES (?, ?, ?, ?)',
    [userId, pluginId, rating, comment]
  )

  const [rows] = await db.query('SELECT * FROM reviews WHERE id = ?', [result.insertId])
  return rows[0]
}

module.exports = {
  listPlugins,
  getPluginBySlug,
  getPluginById,
  createPlugin,
  updatePlugin,
  deletePlugin,
  getVersions,
  getMedia,
  getReviews,
  addReview,
  userHasPurchased
}
